<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'root');
define('UC_DBNAME', 'manykit');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`manykit`.discuz_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'E9X3s8raSfXef137ofBeGb3fW8r3lez0T2v5EfLf6dgf2dq4u1m33056X40dy213');
define('UC_API', 'http://www.manykit.com/forum/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>