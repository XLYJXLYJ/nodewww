<?php
//Discuz! cache file, DO NOT modify me!
//Identify: fbb5f3cf50a3aec937c75813ca32a034

$domain = array (
  'defaultindex' => 'forum.php',
  'holddomain' => 'www|*blog*|*space*|*bbs*',
  'list' => 
  array (
  ),
  'app' => 
  array (
    'portal' => '',
    'forum' => '',
    'group' => '',
    'home' => '',
    'default' => '',
  ),
  'root' => 
  array (
    'home' => '',
    'group' => '',
    'forum' => '',
    'topic' => '',
    'channel' => '',
  ),
);
?>