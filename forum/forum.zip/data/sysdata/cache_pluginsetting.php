<?php
//Discuz! cache file, DO NOT modify me!
//Identify: e23881f9e60368c6ce5a2239c5f31786

$pluginsetting = array (
);
?>