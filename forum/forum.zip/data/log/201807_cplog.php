<?PHP exit;?>	1533031180	admin	1	113.104.194.217		GET={}; POST={};
<?PHP exit;?>	1533031181	admin	1	113.104.194.217	index	GET={}; POST={};
<?PHP exit;?>	1533031182	admin	1	113.104.194.217	checktools	GET={operation=filecheck; homecheck=yes; inajax=1; ajaxtarget=filecheck_div; }; POST={};
