var rooturl="{site}";
var url="{url}";
var shtml="{html}";