<?php return array (
  'list_per' => '50',
  'fenye_style' => '1',
  'is_prevent_reg'=>false,
  'prevent_reg_num'=>'2',
  'admin_count_num'=>'100',
  'home_back_bg'=>'/Public/images/body.jpg',
  'is_limit_time'=>false,
  'limit_time'=>'10',
  'bid_init'=>'100'
); ?>