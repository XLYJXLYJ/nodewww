<?php
	return array(
		'site_title'=>'PHP社区--YouYaX开源论坛',
		'site_title_mobile'=>'YouYaX手机版',
		'site_keywords'=>'PHP,框架,论坛',
		'site_description'=>'自主开发设计论坛',
		'site_logo'=>'http://www.youyax.com/logo2.gif',
		'site_foot'=>'新社区新活力'
	);
?>