<?php
return array(
	array('title'   =>'Home Page',
				'url'     =>'http://www.youyax.com',
				'seclists'=> array(
													array('title'=>'Manual','url'=>'http://www.youyax.com/user_guide'),
													array('title'=>'Donation','url'=>'http://www.youyax.com/license.html')
												  )
			 ),
	array('title'   =>'Products',
				'url'     =>'javascript:void(0)',
				'seclists'=> array(
													array('title'=>'Open BBS','url'=>'http://bbs.youyax.com'),
													array('title'=>'Analog Alert','url'=>'http://www.youyax.com/Tip')
												  )
			 )
)
?>