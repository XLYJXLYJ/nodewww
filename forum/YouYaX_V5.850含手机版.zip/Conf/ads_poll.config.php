<?php
	return array(
		array('img'=>'','title'=>'','url'=>'','ord'=>''),
		array('img'=>'','title'=>'','url'=>'','ord'=>''),
		array('img'=>'','title'=>'','url'=>'','ord'=>''),
		array('img'=>'','title'=>'','url'=>'','ord'=>''),
		array('img'=>'','title'=>'','url'=>'','ord'=>'')
	);
?>