<?php
	return array(
		'垃圾'=>'la ji',
		'sb'=>'**'
	);
?>