<?php
return array(
    'db_host' => '{host}',
    'db_name' => '{name}',
    'db_user' => '{user}',
    'db_pwd' => '{pass}',
    'db_prefix' => '{prefix}',
    'default_language' => '{lang}',
    'default_url' => '{url}',
    'static_url' => '{html}',
    'default_action' => '{action}',
    'SITE' => '{site}',
    'seo_set' => 'off',
    'register_mode'=>'1',
    'default_user_group'=>'',
    'not_log_in_user_group'=>''
);
?>