<?php
return array(
	array('title'   =>'主页',
				'url'     =>'http://www.youyax.com',
				'seclists'=> array(
													array('title'=>'开发手册','url'=>'http://www.youyax.com/user_guide'),
													array('title'=>'热心捐赠','url'=>'http://www.youyax.com/license.html')
												  )
			 ),
	array('title'   =>'开源产品',
				'url'     =>'javascript:void(0)',
				'seclists'=> array(
													array('title'=>'开源社区','url'=>'http://bbs.youyax.com'),
													array('title'=>'模拟alert','url'=>'http://www.youyax.com/Tip')
												  )
			 )
)
?>