<?php
	return array(
		'mail_Host'=>'',
		'mail_Username'=>'',
		'mail_Password'=>'',
		'mail_From'=>'',
		'mail_FromName'=>'YouYaX',
		'mail_Subject'=>'YouYaX开源论坛用户激活邮件',
		'mail_Body'=>'欢迎您的注册，请体验此社区的魅力'
	);
?>