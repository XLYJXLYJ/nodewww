<?php
return array(
    'app_id' => '',
    'app_secret' => ''
);
?>