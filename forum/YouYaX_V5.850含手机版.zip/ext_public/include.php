<?php
	$config=include('../Conf/config.php');
	define("url_site",$config['SITE']);
?>