<?php
	return array(
		'home_version1'=>'中文版',
		'home_version2'=>'英文版'
	);
?>