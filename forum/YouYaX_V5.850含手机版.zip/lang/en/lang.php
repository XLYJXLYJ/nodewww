<?php
	return array(
		'home_version1'=>'Chinese',
		'home_version2'=>'English'
	);
?>